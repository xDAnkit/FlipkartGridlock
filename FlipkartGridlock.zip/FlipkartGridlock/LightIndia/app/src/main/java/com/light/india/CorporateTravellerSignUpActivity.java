package com.light.india;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CorporateTravellerSignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_corporate_traveller_sign_up);
    }
}
