package com.light.india;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.light.india.Adapter.AdapterBuses;
import com.light.india.Adapter.AdapterParking;
import com.light.india.Adapter.AdapterRoutes;
import com.light.india.Names.BusMiscellaneous;
import com.light.india.Names.RoutesMiscellaneous;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ParkingFinderActivity extends AppCompatActivity {


    String REQUEST_TAG = "com.light.india";
    private Menu optionsMenu;
    private RecyclerView listMiscellaneous;
    private ArrayList<BusMiscellaneous> busMiscellaneous = new ArrayList<>();
    private ArrayList<RoutesMiscellaneous> routeMiscellaneous = new ArrayList<>();
    private AdapterParking adapterParking;
    private SwipeRefreshLayout swipeRefreshLayout;
    public ProgressBar progressView;
    TextView loading, toolbarTitle;
    int socketTimeout = 30000;//30 seconds - for Volley Retry
    int ID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_finder);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        listMiscellaneous = (RecyclerView) findViewById(R.id.listMiscellaneous);
        listMiscellaneous.setLayoutManager(new LinearLayoutManager(this));
        adapterParking = new AdapterParking(this);
        listMiscellaneous.setAdapter(adapterParking);

        getRoutes();
    }

    private void getRoutes() {

        final HashMap<String, String> params = new HashMap<String, String>();

        final JSONObject jsonObject = new JSONObject(params);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET,
                getRoutesRequestUrl(),
                jsonObject,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        routeMiscellaneous = parseRoutesJsonResponse(response);
                        adapterParking.setMiscellaneousList(routeMiscellaneous);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), ""+error, Toast.LENGTH_SHORT).show();
                /*refreshing();
                setActions();*/

            }
        });
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        request.setRetryPolicy(policy);
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(request, REQUEST_TAG);
    }

    private String getRoutesRequestUrl() {

        return UrlEndPoints.MAIN_URL
                + UrlEndPoints.GET_ROUTES;
    }

    private ArrayList<RoutesMiscellaneous> parseRoutesJsonResponse(JSONObject response) {
        ArrayList<RoutesMiscellaneous> MiscellaneousList = new ArrayList<>();
        if (response != null && response.length() > 0) {

            try {
                JSONArray arrayMiscellaneous = response.getJSONArray(Keys.Routes.KEY_ROUTES);
                for (int i = 0; i < arrayMiscellaneous.length(); i++) {

                    String BusStation = Constants.NA;

                    JSONObject currentMiscellaneous = arrayMiscellaneous.getJSONObject(i);

                    if (contains(currentMiscellaneous, Keys.Routes.KEY_STATION)) {
                        BusStation = currentMiscellaneous.getString(Keys.Routes.KEY_STATION);
                    }

                    RoutesMiscellaneous routeMiscellaneous = new RoutesMiscellaneous();
                    routeMiscellaneous.setPoint(BusStation);
                    if (!BusStation.equals(Constants.NA)) {
                        MiscellaneousList.add(routeMiscellaneous);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return MiscellaneousList;
    }


    private boolean contains(JSONObject jsonObject, String key) {
        return jsonObject != null && jsonObject.has(key) && !jsonObject.isNull(key) ? true : false;
    }
}