package com.light.india.Names;

/**
 * Created by AnkiT Jain on 12-12-2015.
 */
public class RoutesMiscellaneous {

    private String point;
    private String latLong;

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getLatLong() {
        return latLong;
    }

    public void setLatLong(String latLong) {
        this.latLong = latLong;
    }
}