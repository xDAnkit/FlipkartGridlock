package com.light.india;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.light.india.Adapter.AdapterBuses;
import com.light.india.Adapter.AdapterRoutes;
import com.light.india.Names.BusMiscellaneous;
import com.light.india.Names.RoutesMiscellaneous;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

public class LiveBusActivity extends AppCompatActivity {

    String REQUEST_TAG = "com.light.india";
    private Menu optionsMenu;
    private RecyclerView listMiscellaneous;
    private ArrayList<BusMiscellaneous> busMiscellaneous = new ArrayList<>();
    private ArrayList<RoutesMiscellaneous> routeMiscellaneous = new ArrayList<>();
    private AdapterBuses adapterBuses;
    private AdapterRoutes adapterRoutes;
    private SwipeRefreshLayout swipeRefreshLayout;
    public ProgressBar progressView;
    TextView loading, toolbarTitle;
    int socketTimeout = 30000;//30 seconds - for Volley Retry
    int ID = 0;

    EditText etSource, etDestination;
    Button btnSearchBuses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_bus);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        listMiscellaneous = (RecyclerView) findViewById(R.id.listMiscellaneous);
        listMiscellaneous.setLayoutManager(new LinearLayoutManager(this));
        adapterBuses = new AdapterBuses(this);
        listMiscellaneous.setAdapter(adapterBuses);

        etSource = (EditText) findViewById(R.id.et_source);
        etDestination = (EditText) findViewById(R.id.et_destination);
        btnSearchBuses = (Button) findViewById(R.id.btn_search_buses);

        etSource.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStations();
            }
        });

        etDestination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showStations();
            }
        });


        btnSearchBuses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (etSource.getText().equals("")){
                    Toast.makeText(LiveBusActivity.this, "Please select source station", Toast.LENGTH_SHORT).show();
                }

                if (etDestination.getText().equals("")){
                    Toast.makeText(LiveBusActivity.this, "Please select destination station", Toast.LENGTH_SHORT).show();
                }

                if (!etSource.getText().equals("") && !etDestination.getText().equals("")){
                    sendWebRequest();
                }
            }
        });

        sendWebRequest();
    }

    public interface OnItemClickListener {
        void onItemClick(BusMiscellaneous item);
    }

    public void showStations() {
        getRoutes();

        String title = "Select bus stop";
        MaterialDialog dialog = new MaterialDialog.Builder(LiveBusActivity.this)
                .title(title)
                .customView(R.layout.fragment_dialog, false)
                .positiveText("OK")
                .build();

        View view = dialog.getCustomView();
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        adapterRoutes = new AdapterRoutes(this);
        recyclerView.setAdapter(adapterRoutes);
        dialog.show();
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        this.optionsMenu = menu;
        MenuInflater inflater = getMenuInflater();
        //inflater.inflate(R.menu.account, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private void sendWebRequest() {

        final HashMap<String, String> params = new HashMap<String, String>();
        params.put("source", "Pune Airport, Viman nagar, Lohegaon");
        params.put("destination", "Sangvi Phata, Bharat Electronics Colony, Pimple Nilakh, Pimpri-Chinchwad, Maharashtra 411027");
        params.put("acEnabled", ""+true);

        final JSONObject jsonObject = new JSONObject(params);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,
                getRequestUrl(),
                jsonObject,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        busMiscellaneous = parseJsonResponse(response);
                        adapterBuses.setMiscellaneousList(busMiscellaneous);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), ""+error, Toast.LENGTH_SHORT).show();
                /*refreshing();
                setActions();*/

            }
        });
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        request.setRetryPolicy(policy);
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(request, REQUEST_TAG);
    }

    private void getRoutes() {

        final HashMap<String, String> params = new HashMap<String, String>();

        final JSONObject jsonObject = new JSONObject(params);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET,
                getRoutesRequestUrl(),
                jsonObject,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        routeMiscellaneous = parseRoutesJsonResponse(response);
                        adapterRoutes.setMiscellaneousList(routeMiscellaneous);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), ""+error, Toast.LENGTH_SHORT).show();
                /*refreshing();
                setActions();*/

            }
        });
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        request.setRetryPolicy(policy);
        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(request, REQUEST_TAG);
    }

    private String getRoutesRequestUrl() {

        return UrlEndPoints.MAIN_URL
                + UrlEndPoints.GET_ROUTES;
    }

    private void setActions() {
        loading.setVisibility(View.GONE);
        progressView.setVisibility(View.GONE);
    }


    public String getRequestUrl() {

        return UrlEndPoints.MAIN_URL
                + UrlEndPoints.FIND_BUSES;
    }

    private ArrayList<BusMiscellaneous> parseJsonResponse(JSONObject response) {
        ArrayList<BusMiscellaneous> MiscellaneousList = new ArrayList<>();
        if (response != null && response.length() > 0) {

            try {
                JSONArray arrayMiscellaneous = response.getJSONArray(Keys.Buses.KEY_BUSES);
                for (int i = 0; i < arrayMiscellaneous.length(); i++) {

                    String BusID = Constants.NA;
                    String BusNo = Constants.NA;
                    String TravelCharge = Constants.NA;
                    String Distance = Constants.NA;
                    Boolean AcEnabled = false;

                    JSONObject currentMiscellaneous = arrayMiscellaneous.getJSONObject(i);

                    if (contains(currentMiscellaneous, Keys.Buses.KEY_BUS_ID)) {
                        BusID = currentMiscellaneous.getString(Keys.Buses.KEY_BUS_ID);
                    }

                    if (contains(currentMiscellaneous, Keys.Buses.KEY_BUS_NO)) {
                        BusNo = currentMiscellaneous.getString(Keys.Buses.KEY_BUS_NO);
                    }

                    if (contains(currentMiscellaneous, Keys.Buses.KEY_CHARGES)) {
                        TravelCharge = currentMiscellaneous.getString(Keys.Buses.KEY_CHARGES);
                    }

                    if (contains(currentMiscellaneous, Keys.Buses.KEY_DISTANCE)) {
                        Distance = currentMiscellaneous.getString(Keys.Buses.KEY_DISTANCE);
                    }

                    if (contains(currentMiscellaneous, Keys.Buses.KEY_AC_ENABLED)) {
                        AcEnabled = currentMiscellaneous.getBoolean(Keys.Buses.KEY_AC_ENABLED);
                    }

                    BusMiscellaneous busMiscellaneous = new BusMiscellaneous();
                    busMiscellaneous.setBusID(BusID);
                    busMiscellaneous.setBusNo(BusNo);
                    busMiscellaneous.setCharges(TravelCharge);
                    busMiscellaneous.setDistance(Distance);
                    busMiscellaneous.setAcEnabled(AcEnabled);
                    if (!BusID.equals(Constants.NA)) {
                        MiscellaneousList.add(busMiscellaneous);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return MiscellaneousList;
    }

    private ArrayList<RoutesMiscellaneous> parseRoutesJsonResponse(JSONObject response) {
        ArrayList<RoutesMiscellaneous> MiscellaneousList = new ArrayList<>();
        if (response != null && response.length() > 0) {

            try {
                JSONArray arrayMiscellaneous = response.getJSONArray(Keys.Routes.KEY_ROUTES);
                for (int i = 0; i < arrayMiscellaneous.length(); i++) {

                    String BusStation = Constants.NA;

                    JSONObject currentMiscellaneous = arrayMiscellaneous.getJSONObject(i);

                    if (contains(currentMiscellaneous, Keys.Routes.KEY_STATION)) {
                        BusStation = currentMiscellaneous.getString(Keys.Routes.KEY_STATION);
                    }

                    RoutesMiscellaneous routeMiscellaneous = new RoutesMiscellaneous();
                    routeMiscellaneous.setPoint(BusStation);
                    if (!BusStation.equals(Constants.NA)) {
                        MiscellaneousList.add(routeMiscellaneous);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return MiscellaneousList;
    }


    private boolean contains(JSONObject jsonObject, String key) {
        return jsonObject != null && jsonObject.has(key) && !jsonObject.isNull(key) ? true : false;
    }
}