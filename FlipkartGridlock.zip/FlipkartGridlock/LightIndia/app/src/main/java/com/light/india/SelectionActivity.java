package com.light.india;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.afollestad.materialdialogs.MaterialDialog;

public class SelectionActivity extends AppCompatActivity {

    MaterialDialog dialog;
    RelativeLayout rlConductor, rlTraveller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);
        rlConductor = (RelativeLayout) findViewById(R.id.rl_conductor);
        rlTraveller = (RelativeLayout) findViewById(R.id.rl_traveller);

        rlTraveller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectAccountType();
            }
        });
    }

    private void selectAccountType() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle("Are you an office traveller");
        dialogBuilder.setMessage("Please let us know if you're a corporate traveller to avail corporate plans");
        dialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                startActivity(new Intent(getApplicationContext(), NormalTravellerSignUpActivity.class));
            }
        });
        dialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                startActivity(new Intent(getApplicationContext(), CorporateTravellerSignUpActivity.class));
            }
        });
        AlertDialog b = dialogBuilder.create();
        b.show();

    }

    public void DialogLoader(String msg) {
        MaterialDialog.Builder builder = new MaterialDialog.Builder(this)
                .content(msg)
                .progress(true, 0)
                .progressIndeterminateStyle(true)
                .widgetColorRes(R.color.colorPrimary)
                .cancelable(false)
                .progress(true, 0);
        dialog = builder.build();
        dialog.show();

    }
}
