package com.light.india;

import android.net.Uri;

/**
 * Created by xD AnkiT on 11/8/2015.
 */
public interface Constants {
    String NA = "NA";
    String COD = "Cash On Delivery";
    String CustomerName = "";
    String CustomerEmail = "";
    Uri CustomerProfilePicture = null;
    String CustomerID = "";

}
