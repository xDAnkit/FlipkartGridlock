package com.light.india.Adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.light.india.Names.BusMiscellaneous;
import com.light.india.R;
import com.light.india.VolleySingleton;

import java.util.ArrayList;
import java.util.Random;


/**
 * Created by AnkiT Jain on 23-11-2015.
 */
public class AdapterBuses extends RecyclerView.Adapter<AdapterBuses.ViewHolderHomework> {

    private ArrayList<BusMiscellaneous> listMiscellaneous = new ArrayList<>();
    private LayoutInflater layoutInflater;
    private VolleySingleton volleySingleton;
    Random rand = new Random();
    private final static int FADE_DURATION = 1000; // in milliseconds
    private Context context;
    MaterialDialog dialog;
//    ImageLoader imageLoader = AppController.getInstance().getImageLoader();


    public AdapterBuses(Context context) {
        layoutInflater = LayoutInflater.from(context);

    }

    public void setMiscellaneousList(ArrayList<BusMiscellaneous> listMiscellaneous) {

        this.listMiscellaneous = listMiscellaneous;


        notifyItemRangeChanged(0, listMiscellaneous.size());
    }

    @Override
    public ViewHolderHomework onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.content_buses_list, parent, false);
        ViewHolderHomework viewHolder = new ViewHolderHomework(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolderHomework holder, int position) {

        BusMiscellaneous currentMiscellaneous = listMiscellaneous.get(position);
        holder.BusID.setText(currentMiscellaneous.getBusID() + currentMiscellaneous.getBusNo());
        holder.busDistance.setText(currentMiscellaneous.getDistance() + " away");
        holder.travelCharge.setText("\u20B9 " + currentMiscellaneous.getCharges() + "/- fare");
        holder.busDistance.setText(currentMiscellaneous.getDistance());

        if (currentMiscellaneous.getAcEnabled()) {
            holder.acFlag.setVisibility(View.VISIBLE);
        } else {
            holder.acFlag.setVisibility(View.GONE);
        }
        holder.busDistance.setText(currentMiscellaneous.getDistance());

    }


    @Override
    public int getItemCount() {
        return listMiscellaneous.size();
    }


    class ViewHolderHomework extends RecyclerView.ViewHolder implements View.OnClickListener {


        private TextView BusID;
        private TextView busView;
        private ImageView acFlag;
        private TextView travelCharge;
        private TextView busDistance;


        public ViewHolderHomework(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            BusID = (TextView) itemView.findViewById(R.id.bus_id);
            busView = (TextView) itemView.findViewById(R.id.view_btn);
            acFlag = (ImageView) itemView.findViewById(R.id.ac_flag);
            travelCharge = (TextView) itemView.findViewById(R.id.bus_fare);
            busDistance = (TextView) itemView.findViewById(R.id.bus_distance);
        }


        @Override
        public void onClick(View view) {

           /* Snackbar.make(view, "Replace with your own action"+GoalID.getText(), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

            Intent intent = new Intent(view.getContext(), GoalItemActivity.class);
            Bundle bundle = new Bundle();
            bundle.putString("goalID", GoalID.getText().toString());
            bundle.putString("goalTitle", GoalTitle.getText().toString());
            bundle.putString("goalPrice", GoalPrice.getText().toString());
            bundle.putString("goalCreated", GoalCreated.getText().toString());
            bundle.putString("goalTargetDate", GoalTargetDate.getText().toString());
            intent.putExtras(bundle);
            view.getContext().startActivity(intent);*/
        }
    }
}
