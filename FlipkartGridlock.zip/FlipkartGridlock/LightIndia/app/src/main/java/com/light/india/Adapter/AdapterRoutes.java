package com.light.india.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.light.india.Names.BusMiscellaneous;
import com.light.india.Names.RoutesMiscellaneous;
import com.light.india.R;
import com.light.india.VolleySingleton;

import java.util.ArrayList;
import java.util.Random;


/**
 * Created by AnkiT Jain on 23-11-2015.
 */
public class AdapterRoutes extends RecyclerView.Adapter<AdapterRoutes.ViewHolderHomework> {

    private ArrayList<RoutesMiscellaneous> listMiscellaneous = new ArrayList<>();
    private LayoutInflater layoutInflater;
    private VolleySingleton volleySingleton;
    Random rand = new Random();
    private final static int FADE_DURATION = 1000; // in milliseconds
    private Context context;
    MaterialDialog dialog;
//    ImageLoader imageLoader = AppController.getInstance().getImageLoader();


    public AdapterRoutes(Context context) {
        layoutInflater = LayoutInflater.from(context);

    }

    public void setMiscellaneousList(ArrayList<RoutesMiscellaneous> listMiscellaneous) {

        this.listMiscellaneous = listMiscellaneous;


        notifyItemRangeChanged(0, listMiscellaneous.size());
    }

    @Override
    public ViewHolderHomework onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.content_routes, parent, false);
        ViewHolderHomework viewHolder = new ViewHolderHomework(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolderHomework holder, int position) {

        RoutesMiscellaneous currentMiscellaneous = listMiscellaneous.get(position);
        holder.RouteName.setText(currentMiscellaneous.getPoint());

    }


    @Override
    public int getItemCount() {
        return listMiscellaneous.size();
    }


    class ViewHolderHomework extends RecyclerView.ViewHolder implements View.OnClickListener {


        private TextView RouteName;


        public ViewHolderHomework(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            RouteName = (TextView) itemView.findViewById(R.id.route_name);
        }


        @Override
        public void onClick(View view) {
        }
    }
}
