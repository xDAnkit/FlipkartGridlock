package com.light.india.Names;

/**
 * Created by AnkiT Jain on 12-12-2015.
 */
public class BusMiscellaneous {

    private String busNo;
    private String BusID;
    private Boolean acEnabled;
    private String currentLocation;
    private String point;
    private String latLong;
    private String distance;
    private String charges;

    public String getBusNo() {
        return busNo;
    }

    public void setBusNo(String busNo) {
        this.busNo = busNo;
    }

    public String getBusID() {
        return BusID;
    }

    public void setBusID(String busID) {
        BusID = busID;
    }

    public Boolean getAcEnabled() {
        return acEnabled;
    }

    public void setAcEnabled(Boolean acEnabled) {
        this.acEnabled = acEnabled;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getLatLong() {
        return latLong;
    }

    public void setLatLong(String latLong) {
        this.latLong = latLong;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getCharges() {
        return charges;
    }

    public void setCharges(String charges) {
        this.charges = charges;
    }
}