package com.light.india;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class CustomerDashboardActivity extends AppCompatActivity {

    RelativeLayout rlLiveBuses, rlBusBooking, rlParkingFinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard);

        rlLiveBuses = (RelativeLayout) findViewById(R.id.rl_live_buses);
        rlBusBooking = (RelativeLayout) findViewById(R.id.rl_bus_booking);
        rlParkingFinder = (RelativeLayout) findViewById(R.id.rl_find_parking);

        rlLiveBuses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LiveBusActivity.class));
            }
        });

        rlBusBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), BusBookingActivity.class));
            }
        });

        rlParkingFinder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ParkingFinderActivity.class));
            }
        });
    }
}
