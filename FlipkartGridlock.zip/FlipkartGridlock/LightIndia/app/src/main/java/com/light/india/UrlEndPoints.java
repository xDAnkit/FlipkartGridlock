package com.light.india;
/**
 * Created by xD AnkiT on 11/7/2015.
 */
public class UrlEndPoints {



    public UrlEndPoints() {

    }

    public static final String MAIN_URL = "http://192.168.0.4:3000/users/";
    public static final String FIND_BUSES = "search_buses";
    public static final String GET_ROUTES = "routes";


}