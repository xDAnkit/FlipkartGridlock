package com.light.india;

/**
 * Created by xD AnkiT on 11/7/2015.
 */
public interface Keys {


    public interface Buses{

        public static final String KEY_BUSES = "buses";
        public static final String KEY_BUS_ID = "busID";
        public static final String KEY_BUS_NO = "busNo";
        public static final String KEY_AC_ENABLED = "aCEnabled";
        public static final String KEY_CURRENT_LOCATION= "currentLocation";
        public static final String KEY_DISTANCE= "distance";
        public static final String KEY_CHARGES= "charge";
    }
    public interface Routes{

        public static final String KEY_ROUTES= "routes";
        public static final String KEY_STATION = "point";
        public static final String KEY_LAT_LONG = "latLong";
    }
    public interface Customer{

        public static final String KEY_CUSTOMER = "Customer";
        public static final String KEY_CUSTOMER_ID = "CustomerID";
        public static final String KEY_CUSTOMER_NAME = "CustomerName";
        public static final String KEY_CUSTOMER_EMAIL = "CustomerEmail";
        public static final String KEY_CUSTOMER_API_KEY= "CustomerAPIKey";
    }

    public interface GoalsList{

        public static final String KEY_GOALS = "Goals";
        public static final String KEY_GOAL_THUMB= "goalThumb";
        public static final String KEY_GOAL_ID = "GoalID";
        public static final String KEY_GOAL_TITLE = "GoalTitle";
        public static final String KEY_GOAL_PRICE = "GoalPrice";
        public static final String KEY_GOAL_CREATED= "GoalCreated";
        public static final String KEY_GOAL_TARGET_DATE= "GoalTargetDate";
        public static final String KEY_GOAL_STATUS= "GoalStatus";
    }

    public interface GoalsNotifications{

        public static final String KEY_NOTIFICATIONS = "Notifications";
        public static final String KEY_NOTIFICATIONS_THUMB= "NotificationThumb";
        public static final String KEY_NOTIFICATION_ID = "NotificationID";
        public static final String KEY_NOTIFICATION_AMOUNT = "TransactionAmount";
        public static final String KEY_NOTIFICATION_TRANSACTION_REMARK = "TransactionRemark";
        public static final String KEY_NOTIFICATION_MESSAGE= "NotificationMessage";
        public static final String KEY_NOTIFICATION_CREATED= "NotificationCreated";
    }
    public interface Loans{

        public static final String KEY_LOANS = "Loans";
        public static final String KEY_LOAN_ID = "LoanID";
        public static final String KEY_LOAN_ROI = "ROI";
        public static final String KEY_LOAN_TYPE = "LoanType";
        public static final String KEY_LOAN_AMOUNT = "LoanAmount";
        public static final String KEY_LOAN_CATEGORY = "LoanCategory";
        public static final String KEY_LOAN_CREATED = "LoanCreated";
        public static final String KEY_LOAN_EXPIRY = "LoanExpiry";
    }
    public interface Loaners{
        public static final String KEY_LOANERS = "Loaners";
        public static final String KEY_LOANER_ID = "LoanerID";
        public static final String KEY_LOANER_CUSTOMER_ID = "LoanerCustomerID";
        public static final String KEY_LOANER_NAME = "LoanerName";
        public static final String KEY_LOANER_TAGS= "LoanerTags";
        public static final String KEY_LOANER_CATEGORY = "LoanerCategory";
        public static final String KEY_LOANER_CONTACT = "LoanerContact";
        public static final String KEY_LOANER_CITY = "LoanerCity";
    }
    public interface ATM{
        public static final String KEY_ATM = "ATMS";
        public static final String KEY_ATM_ID = "ATMID";
        public static final String KEY_ATM_ADDRESS = "ATMAddress";
        public static final String KEY_ATM_CITY = "ATMCity";
        public static final String KEY_ATM_STATE = "ATMState";
        public static final String KEY_ATM_MONEY_FLAG = "MoneyFlag";
    }
    public interface Expenses{
        public static final String KEY_EXPENSE= "Expenses";
        public static final String KEY_EXPENSE_CATEGORY = "category";
        public static final String KEY_EXPENSE_AMOUNT = "Amount";
        public static final String KEY_EXPENSE_TAG = "tag";
        public static final String KEY_EXPENSE_TYPE = "Transaction";
    }
    public interface Products{
        public static final String KEY_PRODUCTS= "Products";
        public static final String KEY_PRODUCT_ID = "ProductID";
        public static final String KEY_PRODUCT_NAME = "ProductName";
        public static final String KEY_PRODUCT_DESC = "ProductDesc";
        public static final String KEY_PRODUCT_PRICE = "ProductPrice";
        public static final String KEY_PRODUCT_UPDATED= "ProductUpdated";
    }
}
