var express = require('express');
var router = express.Router();
var apiai = require('apiai')
var uuid = require('uuid')
var fs = require('fs')
var mongoose = require('mongoose');
mongoose.Promise = require('bluebird');
const ss = require("string-searching");
var Buses = require('../models/buses');
var Routes = require('../models/routes');
var moment = require('moment')
var geolib = require('geolib')

var request = require('request');


/* GET users listing. */
/* GET home page. */
router.get('/', function (req, res, next) {

    Buses.find(function (err, docs) {
        if (err) return console.error(err);
        console.log(docs);
        res.send(docs);
    })
});

router.get('/routes', function (req, res, next) {

    Routes.find(function (err, docs) {
        if (err) return console.error(err);
        console.log(docs[0]);
        res.send(docs[0]);
    })
});

router.get('/distance', function (req, res, next) {

    /*    var source = commaSeperated("18.581838, 73.793986");
     var destination = commaSeperated("18.576794, 73.898700")
     var data = geolib.getDistance(
     source,
     destination
     );

     var data = (data/1000).toFixed(2);
     var time = ((data/35)*60);

     res.status(200).send({distance : data+" KM",time: time})*/

    var CurrentLocation = "18.576794,%2073.898700"
    var StationLocation = "18.581838,%2073.793986"
    var URL = "https://maps.googleapis.com/maps/api/directions/json?origin="
    var APIKey = "AIzaSyD-3z4UiyTyI5n9LaZGHra7iERknjA07Bk"
    var response = {};

    var finalURL = URL + CurrentLocation + "&destination=" + StationLocation + "&key=" + APIKey

    request(finalURL, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            var obj = JSON.parse(body)
            response = {
                distance: obj.routes[0].legs[0].distance.text,
                duration: obj.routes[0].legs[0].duration.text,
                currentLocation: obj.routes[0].legs[0].end_address,
                reachingLocation: obj.routes[0].legs[0].start_address,
            }
            res.status(200).send(response)
        }
    })
});
router.post('/search_buses', function (req, res, next) {

    var source = req.body.source;
    var destination = req.body.destination;
    var acEnabled = req.body.acEnabled;

    if (source == "" || source == undefined || source == null) {
        res.status(400).send({
            "statusMsg": "Source station is required"
        })
        return;
    }

    if (destination == "" || destination == undefined || destination == null) {
        res.status(400).send({
            "statusMsg": "Destination station is required"
        })
        return;
    }

    if (acEnabled == "false" || acEnabled == false || acEnabled == undefined || acEnabled == "") {
        acEnabled = false;
    } else {
        acEnabled = true;
    }

    var searchQuery = {
        aCEnabled: acEnabled
    }
    var busList = [];
    var busInfo = {};
    var sourceLatLong = "";

    Buses.find(searchQuery, function (err, docs) {
        if (err) return console.error(err);
        docs.forEach(function (obj) {

            var data = obj.routes;
            if (data.length == 0) {
                var response = prepareJSON("No buses found", 400)
                res.status(400).send(response)
            }
            for (i = 0; i < data.length; i++) {
                if (data[i].point == source) {
                    sourceLatLong = data[i].latLong;
                    for (i = 0; i < data.length; i++) {
                        if (data[i].point == destination) {

                            console.log("Seeter" + data[i])
                            var distanceInfo = calculateDistance(obj.currentLocation, data[i].latLong);
                            var travelDistance = calculateDistance(sourceLatLong, data[i].latLong)
                            var travelAmount = calculateTravelAmount(travelDistance, acEnabled)
                            console.log("Info" + distanceInfo)
                            busInfo = {
                                busNo: obj.busNo,
                                busID: obj.busID,
                                acEnabled: obj.aCEnabled,
                                router: obj.routes,
                                distance: travelDistance,
                                charge: travelAmount
                            }

                            busList.push(busInfo);
                        }
                    }

                }
            }
        });


        if (!isObjectEmpty(busList)) {

            var response = prepareJSON("No buses found", 400)
            res.status(400).send(response)
        } else {

            res.status(200).send({buses: busList})
        }

    })
});

function commaSeperated(data) {

    var splits = data.split(",");
    var response = {
        latitude: splits[0],
        longitude: splits[1]
    }

    return response;
}

function isObjectEmpty(obj) {
    return !!Object.keys(obj).length;
}

function findDistance(l1, l2) {

    var CurrentLocation = l1
    var StationLocation = l2
    var URL = "https://maps.googleapis.com/maps/api/directions/json?origin="
    var APIKey = "AIzaSyD-3z4UiyTyI5n9LaZGHra7iERknjA07Bk"
    var response = {};

    var finalURL = URL + CurrentLocation + "&destination=" + StationLocation + "&key=" + APIKey

    request(finalURL, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            var obj = JSON.parse(body)
            response = {
                distance: obj.routes[0].legs[0].distance.text,
                duration: obj.routes[0].legs[0].duration.text,
                currentLocation: obj.routes[0].legs[0].end_address,
                reachingLocation: obj.routes[0].legs[0].start_address,
            }
            console.log(response)
            return response;
        }
    })

}

function calculateTravelAmount(travelDistance, acEnabled) {

    var travelCharge = 10;
    if (travelDistance < 5) {

        travelCharge = 10
    }
    else if (travelDistance <= 6) {
        travelCharge = 15;
    } else if (travelDistance <= 12) {
        travelCharge = 20;
    } else if (travelDistance <= 18) {
        travelCharge = 25;
    } else {
        travelCharge = 30;
    }

    if (!acEnabled){
        travelCharge = travelCharge + 20;
    }

    return travelCharge;
}

function calculateDistance(l1, l2) {


    var busLocation = commaSeperated(l1);
    var stationLocation = commaSeperated(l2);


    var distance = geolib.getDistance(
        busLocation,
        stationLocation
    );

    return (distance / 1000).toFixed(2) + " KM";
}

function prepareJSON(msg, statusCode) {

    var response = {
        message: msg,
        statusCode: statusCode
    }

    return response;

}

module.exports = router;
