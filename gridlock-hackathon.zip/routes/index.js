    var express = require('express');
    var router = express.Router();
    var apiai = require('apiai')
    var uuid = require('uuid')
    var fs = require('fs')
    var mongoose = require('mongoose');
    mongoose.Promise = require('bluebird');


    module.exports = router;