var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var RoutesSchema = new Schema({
    city: {type: String, required: true},
    currentLocation: {type: String, required: false},
    routes: [{
        point: {type: String, required: false},
        latLong: {type: String, required: false}
    }]
},{collection:"routes"});

var RouteModel = module.exports = mongoose.model('routeModel', RoutesSchema);