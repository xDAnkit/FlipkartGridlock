var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var request = require('request');

var BusesSchema = new Schema({
    busNo: {type: String, required: true},
    busID: {type: String, required: true},
    aCEnabled: {type: Boolean, required: false},
    currentLocation: {type: String, required: false},
    routes: [{
        point: {type: String, required: false},
        latLong: {type: String, required: false}
    }]
},{collection:"buses"});

var BusesModel = module.exports = mongoose.model('busesModel', BusesSchema);

module.exports.findDistance = function(l1,l2, callback){

    var CurrentLocation = l1
    var StationLocation = l2
    var URL = "https://maps.googleapis.com/maps/api/directions/json?origin="
    var APIKey = "AIzaSyD-3z4UiyTyI5n9LaZGHra7iERknjA07Bk"
    var response = {};

    var finalURL = URL + CurrentLocation + "&destination=" + StationLocation + "&key=" + APIKey

    request(finalURL, function (error, response, body) {
        if (!error && response.statusCode == 200) {
            var obj = JSON.parse(body)
            response = {
                distance: obj.routes[0].legs[0].distance.text,
                duration: obj.routes[0].legs[0].duration.text,
                currentLocation: obj.routes[0].legs[0].end_address,
                reachingLocation: obj.routes[0].legs[0].start_address,
            }
            return callback;
        }
    })
}