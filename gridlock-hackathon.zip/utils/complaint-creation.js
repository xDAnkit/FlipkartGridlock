
    var ComplaintModel = require('../models/complaint');

    module.exports.createComplaint = function(newComplaint, isResponseRequired, callback){

    	var complaintModel = new ComplaintModel(newComplaint, false);
    	ComplaintModel.createcustomerComplaint(complaintModel, function(err, result){
    		if(err){
    			if(isResponseRequired == true){
    				var response = {
    					"statusMessage":"Unable to create complaint"
    				};
    				console.log("Error inside")
    				return callback(response);
    			}
    		}else{ console.log("Else insode")
    				if ((isResponseRequired == true)) {

	    				var response = {
	    					"statusMessage":"Complaint created successfully"
	    				};

	    				return callback(response);
    				}
    			}
    	})
    }